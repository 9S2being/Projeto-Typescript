import { Tweet } from "./tweets";

export class User {
  #id: string;
  #name: string;
  #username: string;
  #email: string;
  #password: string;
  #tweets: Tweet[];
  #following: User[];

  constructor(name: string, username: string, email: string, password: string) {
    this.#id = this.generateUniqueId();
    this.#name = name;
    this.#username = username;
    this.#email = email;
    this.#password = password;
    this.#tweets = [];
    this.#following = [];
  }

  private generateUniqueId(): string {
    return Math.random().toString(36).substring(2) + Date.now().toString(36);
  }

  sendTweet(content: string, type: string): void {
    const tweet = new Tweet(this, content, type);
    this.#tweets.push(tweet);
  }

  follow(user: User): void {
    if (user !== this && !this.#following.includes(user)) {
      this.#following.push(user);
    }
  }

  getFollows(): User[] {
    return this.#following;
  }

  showFeedWithDetails(): string {
    const feedTweets = this.#tweets.concat(
      ...this.#following.flatMap((user) => user.getTweets()),
      ...this.#tweets.flatMap((tweet) => tweet.getReplies())
    );

    const formattedTweets = feedTweets.map((tweet) => {
      const likesInfo = tweet.getLikesInfo();
      const repliesInfo = tweet.getRepliesInfo();

      return `${tweet.show()}\n${likesInfo}${repliesInfo}\n`;
    });

    return formattedTweets.join("\n");
  }

  showTweets(): string {
    const userTweets = this.#tweets.concat(...this.#tweets.flatMap((tweet) => tweet.getReplies()));
    return userTweets.map((tweet) => tweet.show()).join("\n\n");
  }

  getTweets(): Tweet[] {
    return this.#tweets;
  }

  getUsername(): string {
    return this.#username;
  }

  likeTweet(tweet: Tweet): void {
    tweet.like(this);
  }

  replyToTweet(tweet: Tweet, content: string): void {
    const reply = new Tweet(this, content, "reply");
    reply.setReplyTo(tweet.getUser());
    tweet.addReply(reply);
  }
}
