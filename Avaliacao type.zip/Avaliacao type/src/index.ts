import { User } from "./users";

// Users
const user1 = new User("Pedro", "Cavalcante", "massa@email", "senha123");
const user2 = new User("Jaquin", "mordekaiser_Main", "jaquinos@email", "senha456");
const user3 = new User("Visconde", "Enaldinho", "donatelo@email", "senha789");

// tweets
user1.sendTweet("Previsões para o jogo do Fortaleza x Cruzeiro", "normal");
user2.sendTweet("Qual o valor de um quarto de hotel em novamburgo", "normal");
user3.sendTweet("Baldurs Gate 3 tem uma vitória esmagadora no GOTY 2023 e presenteia seu público com um desconto de 80% até o fim de dezembro", "normal");

// resposta a tweets
const user1Tweets = user1.getTweets();
const user2Tweets = user2.getTweets();
const user3Tweets = user3.getTweets();

if (user1Tweets.length > 0 && user2Tweets.length > 0) {
  user1.replyToTweet(user2Tweets[0], "provavelmente uns R$ 500 por noite");
  user2.replyToTweet(user1Tweets[0], "Fortaleza");
  user2.replyToTweet(user3Tweets[0], "Opa");
}

// Like
user1.likeTweet(user2Tweets[0]);
user2.likeTweet(user1Tweets[0]);
user2.likeTweet(user3Tweets[0]);

// Feed
console.log(`${user1.getUsername()} Feed:\n`, user1.showFeedWithDetails());
console.log(`${user2.getUsername()} Feed:\n`, user2.showFeedWithDetails());
console.log(`${user3.getUsername()} Feed:\n`, user3.showFeedWithDetails());

// Follow
user1.follow(user2);
user2.follow(user1);
user3.follow(user1);
user3.follow(user2);


const user1Follows = user1.getFollows();
const user2Follows = user2.getFollows();
const user3Follows = user3.getFollows();

console.log(`@${user1.getUsername()} is Following: ${user1Follows.map((user) => `@${user.getUsername()}`).join(", ")}`);
console.log(`@${user2.getUsername()} is Following: ${user2Follows.map((user) => `@${user.getUsername()}`).join(", ")}`);
console.log(`@${user3.getUsername()} is Following: ${user3Follows.map((user) => `@${user.getUsername()}`).join(", ")}`);
