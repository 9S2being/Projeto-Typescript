import { User } from "./users";

export class Tweet {
  #id: string;
  #content: string;
  #type: string;
  #likes: User[];
  #replies: Tweet[];
  #replyTo: User | null;

  constructor(user: User, content: string, type: string) {
    this.#id = this.generateUniqueId();
    this.#content = content;
    this.#type = type;
    this.#likes = [user];
    this.#replies = [];
    this.#replyTo = null;
  }

  private generateUniqueId(): string {
    return Math.random().toString(36).substring(2) + Date.now().toString(36);
  }

  like(user: User): void {
    if (!this.#likes.includes(user)) {
      this.#likes.push(user);
    }
  }

  reply(content: string): void {
    const reply = new Tweet(this.#likes[0], content, "reply");
    reply.setReplyTo(this.#likes[0]);
    this.#replies.push(reply);
  }

  show(): string {
    const replyToInfo = this.#replyTo ? ` (Reply to @${this.#replyTo.getUsername()})` : "";
    return `ID: ${this.#id}/ User: @${this.#likes[0].getUsername()}${replyToInfo}\nContent: ${this.#content}\nType: ${this.#type}\nLikes: ${this.#likes.length}\nReplies: ${this.#replies.length}`;
  }

  showReplies(): string {
    const replyIndicators = this.#replies.map((reply) => `Reply to @${reply.getReplyToUser()?.getUsername()}: ${reply.show()}`);
    return replyIndicators.length > 0 ? "\nReplies:\n" + replyIndicators.join("\n") : "";
  }

  addReply(reply: Tweet): void {
    this.#replies.push(reply);
  }

  getReplies(): Tweet[] {
    return this.#replies;
  }

  setReplyTo(user: User | null): void {
    this.#replyTo = user;
  }

  getUser(): User | null {
    return this.#likes.length > 0 ? this.#likes[0] : null;
  }

  getLikesInfo(): string {
    if (this.#likes.length === 0) {
      return "";
    } else if (this.#likes.length === 1) {
      return `@${this.#likes[0].getUsername()} curtiu`;
    } else {
      const usernames = this.#likes.map((user) => `@${user.getUsername()}`);
      const lastUsername = usernames.pop();
      return `${usernames.join(", ")} e mais ${this.#likes.length - 1} usuários curtiram`;
    }
  }

  getReplyToUser(): User | null {
    return this.#replyTo;
  }

  getRepliesInfo(): string {
    const replyIndicators = this.#replies.map((reply) => {
      const replyToUser = reply.getReplyToUser();
      const replyToInfo = replyToUser ? `> @${replyToUser.getUsername()}: ` : "";
      return `${replyToInfo}${reply.show()}`;
    });

    return replyIndicators.length > 0 ? `\nReplies:\n${replyIndicators.join("\n")}\n` : "";
  }
}
